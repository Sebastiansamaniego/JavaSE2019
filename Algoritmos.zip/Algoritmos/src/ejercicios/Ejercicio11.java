package ejercicios;
// Desarrollar un algoritmo que nos calcule el cuadrado de los 9 primeros números
//naturales
public class Ejercicio11 {
    public static void main(String[] args) {
        for(int i=1 ; i<=9; i++){
            System.out.println( i*i );
        }
    }
}
